"""Core frozen dataclasses for key_jax.

These replace KEY's global-state idiom (global geo, global nz0, global phi,
global L_op, ...) with explicit typed inputs to pure functions.

All arrays are jax.Array so they survive jit/vmap/grad transformations.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
from flax import struct


@struct.dataclass
class FluxTubeGeometry:
    """Flux-tube geometry along the ballooning coordinate theta.

    Mirrors the columns of a GIST file plus the derived Ky. Field names follow
    KEY's `geo` DataFrame conventions so reference-matching is literal.

    theta: (N+1,) ballooning angle in radians, in [-n_pol*pi, n_pol*pi]
    B:     (N+1,) |B|/B_ref
    gxx:   (N+1,) metric tensor g^xx
    gxy:   (N+1,) metric tensor g^xy
    gyy:   (N+1,) metric tensor g^yy  (this is the one that enters L_op)
    J:     (N+1,) Jacobian, (B . grad z)^{-1}
    Ly:    (N+1,) grad-B drift coefficient
    Ky:    (N+1,) curvature-drift coefficient, = Ly - dpdx/(2B)
    dBdz:  (N+1,) parallel B gradient
    """
    theta: jax.Array
    B:     jax.Array
    gxx:   jax.Array
    gxy:   jax.Array
    gyy:   jax.Array
    J:     jax.Array
    Ly:    jax.Array
    Ky:    jax.Array
    dBdz:  jax.Array

    # Scalars — carried here for downstream formulas
    q:     float = struct.field(pytree_node=False)
    shat:  float = struct.field(pytree_node=False)
    major: float = struct.field(pytree_node=False)
    minor: float = struct.field(pytree_node=False)
    Lref:  float = struct.field(pytree_node=False)
    n_pol: int   = struct.field(pytree_node=False)
    B_ref: float = struct.field(pytree_node=False)
    dpdx:  float = struct.field(pytree_node=False)
    nz0:   int   = struct.field(pytree_node=False)


@struct.dataclass
class PlasmaParams:
    """Plasma parameters fed to the KBM eigenvalue problem.

    Normalisations match KEY: kyrho is the KEY convention (sqrt(2) * GENE's).
    Conversion is available via utilities.kyrho_key_from_gene(...).
    """
    beta:  float  # beta_ref,i — depends on B_ref^-2 not on B(theta)^-2
    tau:   float  # T_i / T_e
    kyrho: float  # k_y rho_ref  (KEY convention)
    omti:  float  # L_ref / L_Ti
    omte:  float  # L_ref / L_Te
    omn:   float  # L_ref / L_n

    @property
    def eta_i(self) -> float:
        return self.omti / self.omn

    @property
    def eta_e(self) -> float:
        return self.omte / self.omn


@struct.dataclass
class FDStencils:
    """Finite-difference matrices built from KEY's FCB (FFD/CFD/BFD) scheme.

    D1, D2: (N+1, N+1) matrices for first and second theta derivatives.
    hx: grid spacing in theta.

    KEY uses first-order FFD/BFD at the two edge points and second-order CFD
    everywhere else, matching the 'orig' block in finite_diff_stencil.jl after
    the 2019 edits.
    """
    D1: jax.Array
    D2: jax.Array
    hx: float = struct.field(pytree_node=False)


@struct.dataclass
class MTMResult:
    """Result of an eigenvalue search.

    Omega:       complex eigenvalue in KEY units (omega / omega*_e, sign-flipped
                 so that positive real part = ion diamagnetic direction).
    Omega_gene:  same but in GENE units (omega / (c_s / L_ref)).
    phi:         (N+1,) ballooning eigenmode Phi(theta).
    sigma_min:   achieved smallest singular value of M(Omega). Zero at a true
                 eigenvalue; small positive number in practice.
    resonance_mode: one of {"fluid", "analytic_resonant", "numeric_resonant"}.
    """
    Omega:          jax.Array  # complex scalar
    Omega_gene:     jax.Array  # complex scalar
    phi:            jax.Array
    sigma_min:      jax.Array  # real scalar
    resonance_mode: str = struct.field(pytree_node=False)
