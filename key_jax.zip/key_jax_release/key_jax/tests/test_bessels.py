"""Milestone 3.A: Bessel Gamma functions across all b regimes."""
from __future__ import annotations

import jax
jax.config.update("jax_enable_x64", True)

import numpy as np
import scipy.special as scs
import jax.numpy as jnp

from key_jax import bessels


def test_milestone_3A_Gamma0_at_test_points():
    """Gamma_0(b) = I_0(b)*exp(-b) matches scipy for b from tiny to huge."""
    bs = [0.01, 0.1, 1.0, 10.0, 100.0, 1000.0, 10000.0]
    for b in bs:
        jax_val = float(bessels.Gamma0(b))
        # scipy: i0e(b) = I_0(b)*exp(-|b|), same as what we want
        sci_val = scs.i0e(b)
        rel_err = abs(jax_val - sci_val) / max(abs(sci_val), 1e-30)
        print(f"  b={b:>10g}  Gamma_0(b): jax={jax_val:.6e}, scipy={sci_val:.6e}, rel_err={rel_err:.2e}")
        assert rel_err < 1e-10, f"At b={b}, rel_err={rel_err}"


def test_milestone_3A_Gamma1_at_test_points():
    """Gamma_1(b) = I_1(b)*exp(-b)."""
    bs = [0.01, 0.1, 1.0, 10.0, 100.0, 1000.0, 10000.0]
    for b in bs:
        jax_val = float(bessels.Gamma1(b))
        sci_val = scs.i1e(b)
        rel_err = abs(jax_val - sci_val) / max(abs(sci_val), 1e-30)
        print(f"  b={b:>10g}  Gamma_1(b): jax={jax_val:.6e}, scipy={sci_val:.6e}, rel_err={rel_err:.2e}")
        assert rel_err < 1e-10


def test_milestone_3A_asymptotic_FLR():
    """For b >> 1, Gamma_0(b) ~ 1/sqrt(2 pi b)."""
    b = 1000.0
    G0 = float(bessels.Gamma0(b))
    asymptotic = 1.0 / np.sqrt(2 * np.pi * b)
    rel_err = abs(G0 - asymptotic) / asymptotic
    print(f"  b=1000: Gamma_0 = {G0:.6e}, asymptotic = {asymptotic:.6e}, rel_err = {rel_err:.2e}")
    assert rel_err < 1e-2  # higher-order corrections at this b


def test_milestone_3A_b_computation():
    """b(theta) formula matches KEY convention."""
    kyrho = 0.2
    gyy = jnp.array([1.0, 2.0, 4.0])
    B = jnp.array([1.0, 0.5, 2.0])
    b = bessels.b_of(kyrho, gyy, B)
    expected = 0.5 * 0.2**2 * np.array([1.0, 2.0/0.25, 4.0/4.0])
    assert np.allclose(b, expected)
    print(f"  b-formula check OK, b = {np.asarray(b)}")


def test_milestone_3A_jit_grad():
    """Gamma functions survive jit and grad."""
    g = jax.grad(lambda b: bessels.Gamma0(b).sum())
    val = float(g(0.5))
    # d/db[i0e(b)] should be i1e(b) - i0e(b)
    expected = float(bessels.Gamma1(0.5) - bessels.Gamma0(0.5))
    rel_err = abs(val - expected) / max(abs(expected), 1e-12)
    print(f"  grad(Gamma_0)(0.5) = {val:.4e}, expected = {expected:.4e}, rel_err = {rel_err:.2e}")
    assert rel_err < 1e-8


if __name__ == "__main__":
    print("--- Milestone 3.A: Gamma_0 (I_0 * exp(-b)) ---")
    test_milestone_3A_Gamma0_at_test_points()
    print("--- Milestone 3.A: Gamma_1 (I_1 * exp(-b)) ---")
    test_milestone_3A_Gamma1_at_test_points()
    print("--- Milestone 3.A: asymptotic FLR limit ---")
    test_milestone_3A_asymptotic_FLR()
    print("--- Milestone 3.A: b(theta) formula ---")
    test_milestone_3A_b_computation()
    print("--- Milestone 3.A: jit/grad sanity ---")
    test_milestone_3A_jit_grad()
    print("\n*** All Bessel tests passed ***")
