# key_jax (Phase 1, verified subset)

JAX port of the substrate of Mulholland's KEY code. This release contains
only modules that are 100% verified against ground truth.

**Quick start:**

```bash
pip install jax jaxlib flax numpy scipy

# From this directory:
for f in key_jax/tests/test_*.py; do
  echo "=== $(basename $f) ==="
  PYTHONPATH=. python "$f" 2>&1 | tail -2
done
```

Expected output: `*** All <module> tests passed ***` for all 5 test files.

**For the full explanation of what each module does and how each test
validates it, read `GUIDE.md`.**

## Contents

| Module | Tested | Lines |
|--------|--------|-------|
| `state.py` | (pure dataclasses) | 100 |
| `dispersion.py` | `test_dispersion.py` (7 tests) | 130 |
| `bessels.py` | `test_bessels.py` (5 tests) | 60 |
| `stencils.py` | `test_stencils.py` (4 tests) | 90 |
| `frequencies.py` | `test_frequencies.py` (11 tests) | 140 |
| `q_integrals.py` | `test_q_integrals.py` (8 tests) | 230 |

35 tests total, all passing.

OM TAT SAT.
