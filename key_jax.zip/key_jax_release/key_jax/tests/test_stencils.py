"""Milestone 0.B: FD stencils produce correct derivatives on test functions."""
from __future__ import annotations

import jax
jax.config.update("jax_enable_x64", True)

import numpy as np
import jax.numpy as jnp

from key_jax import stencils


def test_milestone_0B_first_derivative_on_sin():
    """D1 @ sin(theta) ≈ cos(theta) to second order in bulk."""
    nz = 256
    theta = np.asarray(stencils.grid_theta(nz, n_pol=1))
    s = stencils.build_stencils(nz, n_pol=1)
    f = np.sin(theta)
    df_numeric = np.asarray(s.D1 @ jnp.asarray(f))
    df_exact = np.cos(theta)
    # bulk error should be O(h^2)
    bulk_err = np.abs(df_numeric[10:-10] - df_exact[10:-10]).max()
    edge_err = np.abs(df_numeric[[0, -1]] - df_exact[[0, -1]]).max()
    h = s.hx
    print(f"  nz={nz}, h={h:.4e}")
    print(f"  bulk max|D1 f - f'| = {bulk_err:.3e}   (expect ~ h^2 = {h**2:.3e})")
    print(f"  edge max|D1 f - f'| = {edge_err:.3e}   (expect ~ h   = {h:.3e})")
    assert bulk_err < 10 * h**2, "bulk first derivative not 2nd-order"
    assert edge_err < 10 * h, "edge first derivative not 1st-order"


def test_milestone_0B_second_derivative_on_sin():
    """D2 @ sin(theta) ≈ -sin(theta)."""
    nz = 256
    theta = np.asarray(stencils.grid_theta(nz, n_pol=1))
    s = stencils.build_stencils(nz, n_pol=1)
    f = np.sin(theta)
    d2f_numeric = np.asarray(s.D2 @ jnp.asarray(f))
    d2f_exact = -np.sin(theta)
    bulk_err = np.abs(d2f_numeric[10:-10] - d2f_exact[10:-10]).max()
    h = s.hx
    print(f"  bulk max|D2 f - f''| = {bulk_err:.3e}  (expect ~ h^2 = {h**2:.3e})")
    assert bulk_err < 10 * h**2


def test_milestone_0B_convergence_second_order():
    """Halving h should reduce bulk error by ~4x."""
    errs = []
    hs = []
    for nz in [64, 128, 256, 512]:
        theta = np.asarray(stencils.grid_theta(nz, n_pol=1))
        s = stencils.build_stencils(nz, n_pol=1)
        f = np.sin(theta)
        df_numeric = np.asarray(s.D1 @ jnp.asarray(f))
        df_exact = np.cos(theta)
        err = np.abs(df_numeric[20:-20] - df_exact[20:-20]).max()
        errs.append(err)
        hs.append(s.hx)

    for i in range(len(errs) - 1):
        ratio = errs[i] / errs[i + 1]
        print(f"  nz={2**(6+i)}: err={errs[i]:.3e}  ratio={ratio:.2f} (expect ~4)")
    final_ratio = errs[0] / errs[-1]
    expected_ratio = (hs[0] / hs[-1]) ** 2
    print(f"  overall: h reduced by {hs[0]/hs[-1]:.0f}, err by {final_ratio:.1f} (expect ~{expected_ratio:.0f})")
    # Allow some slack — second-order convergence
    assert final_ratio > 0.5 * expected_ratio


def test_milestone_0B_n_pol_scaling():
    """For n_pol=20 (KEY default), grid covers 40*pi and hx scales accordingly."""
    nz = 2560  # KEY's default
    theta = np.asarray(stencils.grid_theta(nz, n_pol=20))
    s = stencils.build_stencils(nz, n_pol=20)
    expected_hx = 2 * np.pi * 20 / nz
    assert abs(s.hx - expected_hx) < 1e-12
    assert abs(theta[0] + 20 * np.pi) < 1e-10
    assert abs(theta[-1] - 20 * np.pi) < 1e-10
    print(f"  n_pol=20: hx={s.hx:.4e}, theta range [{theta[0]:.4f}, {theta[-1]:.4f}]")


if __name__ == "__main__":
    print("--- Milestone 0.B: first derivative on sin(theta) ---")
    test_milestone_0B_first_derivative_on_sin()
    print("--- Milestone 0.B: second derivative on sin(theta) ---")
    test_milestone_0B_second_derivative_on_sin()
    print("--- Milestone 0.B: convergence ---")
    test_milestone_0B_convergence_second_order()
    print("--- Milestone 0.B: n_pol scaling ---")
    test_milestone_0B_n_pol_scaling()
    print("\n*** All stencil tests passed ***")
