"""Tests for frequencies.py — verifies each helper against KEY's formula
in main_key_equations.jl, computed directly in numpy as the cross-check.
"""
from __future__ import annotations

import jax
jax.config.update("jax_enable_x64", True)

import numpy as np
import jax.numpy as jnp

from key_jax.state import FluxTubeGeometry, PlasmaParams
from key_jax import frequencies as fq, stencils


def _make_test_geo(nz=32):
    """Synthetic geometry for cross-checks."""
    theta = np.asarray(stencils.grid_theta(nz, n_pol=1))
    shat = 0.8; eps = 0.18
    B = 1.0 / (1.0 + eps * np.cos(theta))
    gxx = np.ones_like(theta); gxy = shat * theta
    gyy = 1.0 + (shat * theta)**2; J = np.ones_like(theta) / B
    Ky = -(np.cos(theta) + shat * theta * np.sin(theta))
    Ly = Ky.copy(); dBdz = -eps * np.sin(theta) * B**2
    return FluxTubeGeometry(
        theta=jnp.asarray(theta), B=jnp.asarray(B),
        gxx=jnp.asarray(gxx), gxy=jnp.asarray(gxy), gyy=jnp.asarray(gyy),
        J=jnp.asarray(J), Ly=jnp.asarray(Ly), Ky=jnp.asarray(Ky),
        dBdz=jnp.asarray(dBdz),
        q=1.4, shat=shat, major=3.0, minor=0.54,
        Lref=3.0, n_pol=1, B_ref=1.0, dpdx=0.0, nz0=nz,
    )


def _make_test_params():
    return PlasmaParams(beta=0.005, tau=1.5, kyrho=0.2,
                        omti=8.0, omte=4.0, omn=1.5)


def test_omega_star_e_matches_KEY_line_69():
    """KEY: ω_star_e(kyrho, omn) = √2 · 0.5 · kyrho · omn"""
    p = _make_test_params()
    expected = np.sqrt(2.0) * 0.5 * p.kyrho * p.omn
    got = float(fq.omega_star_e(p))
    assert np.isclose(got, expected), f"got {got}, expected {expected}"
    print(f"  ω*_e = √2 · 0.5 · kyρ · ω_n = {got:.6f}  ✓")


def test_omega_star_i_sign_and_magnitude():
    """KEY: ω_star_i = -ω*_e / τ — opposite sign, scaled by 1/τ."""
    p = _make_test_params()
    expected = -fq.omega_star_e(p) / p.tau
    got = float(fq.omega_star_i(p))
    assert np.isclose(got, expected)
    assert got < 0, "ω*_i should be negative when omn > 0"
    print(f"  ω*_i = -ω*_e/τ = {got:.6f}  ✓ (sign correct: ions drift opposite)")


def test_alpha_i_matches_KEY_line_71():
    """KEY: α_i(kyrho, omn, n, Ω, η_i, τ) = 1 + (1/(τΩ)) (1 + n η_i)"""
    p = _make_test_params()
    Omega = 1.0 + 0.3j
    for n in [0, 1]:
        expected = 1.0 + (1.0 / (p.tau * Omega)) * (1.0 + n * p.eta_i)
        got = complex(fq.alpha_i(n, Omega, p))
        assert np.isclose(got, expected), f"α_{{{n},i}}: got {got}, expected {expected}"
        print(f"  α_{{{n},i}}(Ω={Omega}) = {got:.4e}  ✓")


def test_alpha_e_matches_KEY_line_72():
    """KEY: α_e(kyrho, omn, n, Ω, η_e) = 1 - (1/Ω) (1 + n η_e)"""
    p = _make_test_params()
    Omega = 1.0 + 0.3j
    for n in [0, 1]:
        expected = 1.0 - (1.0 / Omega) * (1.0 + n * p.eta_e)
        got = complex(fq.alpha_e(n, Omega, p))
        assert np.isclose(got, expected), f"α_{{{n},e}}: got {got}, expected {expected}"
        print(f"  α_{{{n},e}}(Ω={Omega}) = {got:.4e}  ✓")


def test_epsilon_n_includes_q():
    """KEY's reinstated q: ε_n = q · L_n / L_ref where L_n = L_ref / omn"""
    p = _make_test_params()
    geo = _make_test_geo()
    expected = geo.q * (geo.Lref / p.omn) / geo.Lref  # = q / omn
    got = float(fq.epsilon_n(p, geo))
    assert np.isclose(got, expected)
    print(f"  ε_n = q·L_n/L_ref = {got:.4f}  ✓")


def test_Omega_curv_matches_KEY_line_48():
    """KEY: Ω_curv(omn, τ) = (ε_n / (τ·q)) · Ky(θ)"""
    p = _make_test_params()
    geo = _make_test_geo()
    expected = (float(fq.epsilon_n(p, geo)) / (p.tau * geo.q)) * np.asarray(geo.Ky)
    got = np.asarray(fq.Omega_curv(p, geo))
    assert np.allclose(got, expected)
    print(f"  Ω_κ(θ) shape={got.shape}, range [{got.min():.4f}, {got.max():.4f}]  ✓")


def test_Omega_mag_curv_is_2_times_Omega_curv():
    """KEY line 62: Ω_mag_curv = Ω_gradBeqcurv = 2·Ω_κ"""
    p = _make_test_params()
    geo = _make_test_geo()
    omk = np.asarray(fq.Omega_curv(p, geo))
    omc = np.asarray(fq.Omega_mag_curv(p, geo))
    assert np.allclose(omc, 2.0 * omk)
    print(f"  Ω_mag_curv = 2·Ω_κ  ✓")


def test_b_theta_matches_KEY_line_38():
    """KEY: b(kyrho)(θ) = 0.5 · (kyrho/B(θ))² · g^yy(θ)"""
    p = _make_test_params()
    geo = _make_test_geo()
    expected = 0.5 * (p.kyrho / np.asarray(geo.B))**2 * np.asarray(geo.gyy)
    got = np.asarray(fq.b_theta(p, geo))
    assert np.allclose(got, expected)
    print(f"  b(θ) = ½(kyρ/B)²·g^yy, range [{got.min():.3e}, {got.max():.3e}]  ✓")


def test_xi_squared_relation():
    """ξ² = Ω/(2·Ω_mag_curv) = Ω/(4·Ω_κ) — Mulholland eq. before 4.44, KEY line 143."""
    p = _make_test_params()
    geo = _make_test_geo()
    Omega = 1.0 + 0.5j
    xi = np.asarray(fq.xi_theta(Omega, p, geo))
    Omk_mag = np.asarray(fq.Omega_mag_curv(p, geo))
    expected_xi_sq = Omega / (2.0 * Omk_mag + 0j)
    got_xi_sq = xi * xi
    assert np.allclose(got_xi_sq, expected_xi_sq, atol=1e-12)
    print(f"  ξ² = Ω/(2·Ω_mag_curv)  ✓")


def test_Omega_A_inv_sq_matches_KEY_line_34():
    """KEY: Ω_A(β,τ,omn) = ((β·τ·q²) / (2·B²·ε_n²))^{-0.5}
    so   Ω_A^{-2} = (β·τ·q²) / (2·B²·ε_n²)
    """
    p = _make_test_params()
    geo = _make_test_geo()
    eps_n = float(fq.epsilon_n(p, geo))
    B = np.asarray(geo.B)
    expected = (p.beta * p.tau * geo.q**2) / (2.0 * B**2 * eps_n**2)
    got = np.asarray(fq.Omega_A_inv_sq(p, geo))
    assert np.allclose(got, expected)
    print(f"  Ω_A⁻²(θ) range [{got.min():.4f}, {got.max():.4f}]  ✓")


def test_jit_grad_through_frequencies():
    """Sanity: jit and grad flow through the helpers."""
    geo = _make_test_geo()

    def loss(beta):
        p = PlasmaParams(beta=beta, tau=1.5, kyrho=0.2,
                         omti=8.0, omte=4.0, omn=1.5)
        return jnp.sum(fq.Omega_A_inv_sq(p, geo))
    g = float(jax.grad(loss)(0.005))
    expected = jax.grad(loss)(0.005)
    assert np.isfinite(g)
    print(f"  d(Σ Ω_A⁻²)/dβ at β=0.005 = {g:.4e}  ✓")


if __name__ == "__main__":
    print("--- frequencies vs KEY's main_key_equations.jl ---")
    test_omega_star_e_matches_KEY_line_69()
    test_omega_star_i_sign_and_magnitude()
    test_alpha_i_matches_KEY_line_71()
    test_alpha_e_matches_KEY_line_72()
    test_epsilon_n_includes_q()
    test_Omega_curv_matches_KEY_line_48()
    test_Omega_mag_curv_is_2_times_Omega_curv()
    test_b_theta_matches_KEY_line_38()
    test_xi_squared_relation()
    test_Omega_A_inv_sq_matches_KEY_line_34()
    test_jit_grad_through_frequencies()
    print("\n*** All frequency tests passed ***")
