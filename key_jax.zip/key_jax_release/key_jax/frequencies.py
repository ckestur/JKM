"""Frequency and drift-coefficient helpers for key_jax.

All quantities here are pure functions of (PlasmaParams, FluxTubeGeometry)
mirroring KEY's main_key_equations.jl lines 16–82.

Conventions (KEY)
-----------------
- kyrho is the KEY convention: kyrho_KEY = sqrt(2) * kyrho_GENE
- ω*_e = √2 * 0.5 * kyrho * omn   (positive in electron diamagnetic direction)
- Ω = ω/ω*_e   (KEY's normalised frequency)
- ε_n = q * L_n / L_ref
- The "gradB_eq_curv" choice: Ω_mag_curv = 2 * Ω_κ
  (this is what KEY actually uses everywhere — see line 62)

The factor of q in ε_n was a correction KEY made; the comment on line 22
explains it. Match this exactly.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp

from key_jax.state import FluxTubeGeometry, PlasmaParams


# --- Diamagnetic frequencies (scalars) -------------------------------

def omega_star_e(p: PlasmaParams) -> float:
    """ω*_e / (c_s/L_ref). Positive in electron diamagnetic direction."""
    return jnp.sqrt(2.0) * 0.5 * p.kyrho * p.omn


def omega_star_i(p: PlasmaParams) -> float:
    """ω*_i / (c_s/L_ref). Negative when omn>0 because ions drift opposite."""
    return -omega_star_e(p) / p.tau


def omega_pi(p: PlasmaParams) -> float:
    """ω*_pi = ω*_i (1 + η_i)  — ion-pressure-gradient diamagnetic frequency."""
    return omega_star_i(p) * (1.0 + p.eta_i)


# --- Length-scale and toroidicity ------------------------------------

def Ln(p: PlasmaParams, geo: FluxTubeGeometry) -> float:
    return geo.Lref / p.omn


def epsilon_n(p: PlasmaParams, geo: FluxTubeGeometry) -> float:
    """ε_n = q * L_n / L_ref  (KEY's reinstated q)."""
    return geo.q * Ln(p, geo) / geo.Lref


# --- Alpha coefficients (eq. 4.27 of thesis) -------------------------

def alpha_i(n: int, Omega: jax.Array, p: PlasmaParams) -> jax.Array:
    """α_{n,i} = 1 + (1/(τ Ω)) (1 + n η_i).
    Note: KEY's α_i has + sign on second term (line 71); this is because
    of the ω*_i = -ω*_e/τ sign convention.
    """
    return 1.0 + (1.0 / (p.tau * Omega)) * (1.0 + n * p.eta_i)


def alpha_e(n: int, Omega: jax.Array, p: PlasmaParams) -> jax.Array:
    """α_{n,e} = 1 - (1/Ω) (1 + n η_e)."""
    return 1.0 - (1.0 / Omega) * (1.0 + n * p.eta_e)


# --- Drift frequencies (theta-dependent, returned as arrays) ---------

def Omega_B(p: PlasmaParams, geo: FluxTubeGeometry) -> jax.Array:
    """grad-B drift frequency normalised: Ω_B(θ) = (ε_n / (τ q)) * Ly(θ)."""
    return (epsilon_n(p, geo) / (p.tau * geo.q)) * geo.Ly


def Omega_curv(p: PlasmaParams, geo: FluxTubeGeometry) -> jax.Array:
    """curvature drift frequency normalised: Ω_κ(θ) = (ε_n / (τ q)) * Ky(θ)."""
    return (epsilon_n(p, geo) / (p.tau * geo.q)) * geo.Ky


def Omega_mag_curv(p: PlasmaParams, geo: FluxTubeGeometry) -> jax.Array:
    """The KEY 'gradB_eq_curv' choice: Ω_mag_curv = 2 * Ω_κ.

    This is hardcoded in KEY's line 62 — they tried alternatives but settled
    on this. We expose other variants explicitly via a `drift_model` flag in
    q_integrals.py.
    """
    return 2.0 * Omega_curv(p, geo)


# --- Alfvén frequency (theta-dependent because B(θ) appears) ---------

def Omega_A_inv_sq(p: PlasmaParams, geo: FluxTubeGeometry) -> jax.Array:
    """Returns Ω_A^{-2}(θ) = (β τ q²) / (2 B(θ)² ε_n²).

    This combination appears as the prefactor of the RHS of eq. 4.31.
    Computing the inverse-squared form avoids a sqrt and is what KEY ends
    up using (KEY computes Ω_A then squares-and-inverts later — same thing).
    """
    eps_n = epsilon_n(p, geo)
    return (p.beta * p.tau * geo.q * geo.q) / (2.0 * geo.B * geo.B * eps_n * eps_n)


# --- FLR argument b(θ) -----------------------------------------------

def b_theta(p: PlasmaParams, geo: FluxTubeGeometry) -> jax.Array:
    """b(θ) = (1/2) (kyrho/B(θ))² * g^yy(θ).

    Matches KEY's `b(kyrho)` on line 38. The B(θ)^{-2} accounts for converting
    ρ_thermal,i to ρ_ref (since B varies along θ).
    """
    return 0.5 * (p.kyrho / geo.B)**2 * geo.gyy


# --- xi for the Cheng / dispersion picture --------------------------

def xi_theta(Omega: jax.Array, p: PlasmaParams, geo: FluxTubeGeometry) -> jax.Array:
    """ξ(θ) = sqrt(Ω / (2 * Ω_mag_curv(θ))).

    Matches KEY's line 143. Returns complex array; principal branch.
    Note: 2*Ω_mag_curv = 4*Ω_κ, consistent with thesis Ch. 4 derivation.
    """
    Omk2 = 2.0 * Omega_mag_curv(p, geo)
    return jnp.sqrt(jnp.asarray(Omega, dtype=jnp.complex128) / Omk2)


# --- Unit conversion -------------------------------------------------

def Omega_to_omega_gene(Omega: jax.Array, p: PlasmaParams) -> jax.Array:
    """Convert KEY frequency Ω (= ω/ω*_e) to GENE units ω/(c_s/L_ref).

    Note KEY's sign convention: KEY's positive Ω_r = electron-diamagnetic
    direction, while GENE's positive ω = ion-diamagnetic direction. So the
    conversion is also a sign flip if the user wants 'GENE convention'.
    Here we return KEY's signed frequency in GENE's amplitude scale.
    """
    return Omega * omega_star_e(p)
