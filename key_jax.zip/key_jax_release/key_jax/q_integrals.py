"""The ion velocity-space integral Q for key_jax.

Three variants from Mulholland Ch. 4:

i)   Q_fluid          (eq. 4.29, non-resonant approximation)
ii)  Q_analytic_resonant   (eq. 4.46, Cheng's analytic form using D_0, D_1)
iii) Q_numeric_resonant    (eq. 4.18, full Gauss-Laguerre × Gauss-Hermite)

Each returns a complex array over θ with shape (nz+1,).

Drift-model variants (relevant only for Q_numeric_resonant)
-----------------------------------------------------------
KEY exposes six combinations in main_key_equations.jl lines 197–211:
- full_drift          : ω_κ from Ky, ω_∇B from Ly, both used distinctly
- gradBeqcurv_drift   : ω_∇B → ω_κ (the default, matching what eq. 4.31 assumes)
- curveqgradB_drift   : ω_κ → ω_∇B
- curvature_model_*   : Cheng-style, only ν² term in denominator (no μ)
- gradB_model_*       : only μ term in denominator

We implement the most-used (gradBeqcurv_drift for full toroidal resonance)
and stub the others as keyword-selectable for the §10.3 research direction.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
import numpy as np
import scipy.special as scs

from key_jax.state import FluxTubeGeometry, PlasmaParams
from key_jax import bessels, dispersion, frequencies as fq


# --- (i) Fluid Q -----------------------------------------------------

def Q_fluid(Omega: jax.Array, p: PlasmaParams, geo: FluxTubeGeometry) -> jax.Array:
    """Non-resonant Q (Mulholland eq. 4.29, KEY line 122).

        Q_fluid = α_{0,i} + (Ω_mag_curv/Ω - b) * α_{1,i}

    Valid for ω_Di / |ω| << 1 — the strongly-driven KBM limit.
    """
    Omega = jnp.asarray(Omega, dtype=jnp.complex128)
    a0 = fq.alpha_i(0, Omega, p)
    a1 = fq.alpha_i(1, Omega, p)
    Omk = fq.Omega_mag_curv(p, geo)
    b = fq.b_theta(p, geo)
    return a0 + (Omk / Omega - b) * a1


# --- (ii) Analytic-resonant Q (Cheng) -------------------------------

def Q_cheng(Omega: jax.Array, p: PlasmaParams, geo: FluxTubeGeometry) -> jax.Array:
    """Cheng's analytic-resonant Q (Mulholland eq. 4.46, KEY line 152).

    Important — analytic-continuation subtlety
    ------------------------------------------
    The Cheng integral represents a contour integral along the real ν axis,
    with poles at ν = ±ξ off the real axis. For Im(ξ) > 0, this integral
    equals Z(ξ)/ξ exactly. For Im(ξ) < 0, the correct value is the
    UPPER-HALF-PLANE evaluation reflected: we use ξ_UHP = sign(Im ξ)·ξ and
    apply a sign correction that propagates through D_0 and D_1.

    KEY's main_key_equations.jl line 144 implements this via the trick
        ξ → sign(imag ξ)·ξ
    in Z, then carries the s factor explicitly through D_0, D_1
    (lines 147-148).

    This is NOT a numerical workaround — it's a mathematical necessity
    coming from how the principal-value integral relates to Z. We cannot
    skip it by using a "better" Faddeeva implementation.

    The relations are (Mulholland eq. 4.47-4.48 with KEY's sign trick):
        Z(ξ_UHP) computed via Faddeeva
        D_0(ξ) = -s·ξ/Ω · Z(s·ξ) = -s·Z(s·ξ)/(4·Ω_κ·ξ)
        D_1(ξ) = -ξ²/Ω · (1 + s·ξ·Z(s·ξ)) = -(1 + s·ξ·Z(s·ξ))/(4·Ω_κ)
    where s = sign(Im ξ). At ξ on the real axis (s = 0 in pure form), use s=+1.
    """
    Omega = jnp.asarray(Omega, dtype=jnp.complex128)
    b = fq.b_theta(p, geo)
    G0 = bessels.Gamma0(b)
    G1 = bessels.Gamma1(b)

    xi = fq.xi_theta(Omega, p, geo)
    Omega_kappa = 0.5 * fq.Omega_mag_curv(p, geo)
    # Sign trick: reflect ξ into upper half plane.
    # When ξ is exactly on the real axis (Im ξ = 0), use s = +1.
    s = jnp.where(xi.imag >= 0, 1.0 + 0.0j, -1.0 + 0.0j)
    xi_uhp = s * xi
    Z_uhp = dispersion.Z(xi_uhp)
    # D_0 and D_1 with sign trick
    D0 = -s * Z_uhp / (4.0 * Omega_kappa * xi)
    D1 = -(1.0 + s * xi * Z_uhp) / (4.0 * Omega_kappa)

    bracket1 = (p.tau * Omega + 1.0 - 0.5 * p.eta_i) * G0 + p.eta_i * b * (G1 - G0)
    bracket2 = p.eta_i * G0
    return (1.0 / p.tau) * (bracket1 * D0 + bracket2 * D1)


def Q_analytic_resonant(
    Omega: jax.Array,
    p: PlasmaParams,
    geo: FluxTubeGeometry,
    threshold: float = 5.0,
) -> jax.Array:
    """Hybrid Q: Cheng where |ξ|<threshold, fluid where |ξ|>threshold.

    Mirrors KEY's `Q_analytic_resonant` (line 176). The hybrid is needed
    because Cheng's D_0/D_1 blow up when Ω_mag_curv → 0 (which means
    ξ → ∞), while Q_fluid is the correct asymptotic limit there.

    Implementation: evaluate BOTH branches everywhere then mask via
    jnp.where — wasteful in scalar but correct under jit/vmap, and
    differentiable through the mask.
    """
    xi = fq.xi_theta(Omega, p, geo)
    use_fluid = (jnp.abs(xi.real) > threshold) | (jnp.abs(xi.imag) > threshold)
    Q_c = Q_cheng(Omega, p, geo)
    Q_f = Q_fluid(Omega, p, geo).astype(jnp.complex128)
    return jnp.where(use_fluid, Q_f, Q_c)


# --- (iii) Numeric-resonant Q ---------------------------------------

# Gauss-Laguerre nodes for ∫_0^∞ e^{-μ} f(μ) dμ:
# KEY uses Nmu=11, Nnu=21 by default and Nmu=21, Nnu=31 near marginality.
# Since marginality (where stKBM lives) is the regime we care about most, use
# the higher-N defaults globally — the cost is negligible (vmap'd).
_NMU_DEFAULT = 21
_NNU_DEFAULT = 31
_xmu, _wmu = scs.roots_laguerre(_NMU_DEFAULT)
_xnu, _wnu = scs.roots_hermite(_NNU_DEFAULT)
_XMU = jnp.asarray(_xmu, dtype=jnp.float64)   # (Nmu,)
_WMU = jnp.asarray(_wmu, dtype=jnp.float64)
_XNU = jnp.asarray(_xnu, dtype=jnp.float64)   # (Nnu,)
_WNU = jnp.asarray(_wnu, dtype=jnp.float64)


def Q_numeric_resonant(
    Omega: jax.Array,
    p: PlasmaParams,
    geo: FluxTubeGeometry,
    drift_model: str = "gradBeqcurv",
) -> jax.Array:
    """Full toroidal-resonance Q via 2D Gauss-Laguerre × Gauss-Hermite.

    Mulholland eq. 4.18; KEY lines 197-251.

    Integrand (gradBeqcurv variant, KEY default, line 199):
        F(μ,ν) = J_0²(√(2bμ)) * (τΩ + 1 + η_i (ν² + μ - 3/2))
                  / (Ω - 2 Ω_κ ν² - Ω_κ μ)

    Then  Q = (1/(τ √π)) ∑_{i,j} w_μ(i) w_ν(j) F(μ_i, ν_j)
    The √π is from the Hermite weights normalisation.

    Differentiable: the only Ω-dependence is in the denominator, which is
    smooth as long as the resonance pole is not exactly at a quadrature node.
    For complex Ω with Im(Ω) ≠ 0 the integrand is bounded and smooth.

    drift_model: one of 'gradBeqcurv', 'curveqgradB', 'fulldrift',
                 'curvature_gradBeqcurv', 'gradB_gradBeqcurv'.
                 Default matches KEY's active choice.
    """
    Omega = jnp.asarray(Omega, dtype=jnp.complex128)
    b = fq.b_theta(p, geo)              # (nz+1,)
    Omk = fq.Omega_curv(p, geo)         # (nz+1,)  bare Ω_κ
    OmB = fq.Omega_B(p, geo)            # (nz+1,)  bare Ω_∇B

    # μ, ν grids — broadcast against θ
    mu = _XMU[None, :, None]            # (1, Nmu, 1)
    nu = _XNU[None, None, :]            # (1, 1, Nnu)
    wmu = _WMU[None, :, None]
    wnu = _WNU[None, None, :]
    bb = b[:, None, None]               # (nz+1, 1, 1)
    Okk = Omk[:, None, None]
    OBB = OmB[:, None, None]

    # Bessel factor — J_0 of √(2 b μ). JAX's bessel_jn returns shape
    # (v+1, *z.shape) and produces NaN at z=0, so we handle that case.
    arg = jnp.sqrt(2.0 * bb * mu)               # (nz+1, Nmu, 1)
    # bessel_jn(z, v=0) -> (1, *z.shape); squeeze leading axis
    J0_raw = jax.scipy.special.bessel_jn(arg, v=0)[0]
    # Replace NaN at arg≈0 with the analytic limit J_0(0) = 1.
    # `jnp.where` is differentiable and the gradient at z=0 is 0 (which is
    # correct: dJ_0/dz|_{z=0} = 0).
    J0 = jnp.where(arg < 1e-300, 1.0, J0_raw)
    J0sq = J0 * J0

    # Numerator (real-valued except for τΩ part):
    num = p.tau * Omega + 1.0 + p.eta_i * (nu * nu + mu - 1.5)

    # Denominator — depends on drift model
    if drift_model == "gradBeqcurv":
        denom = Omega - 2.0 * Okk * nu * nu - Okk * mu
    elif drift_model == "curveqgradB":
        denom = Omega - 2.0 * OBB * nu * nu - OBB * mu
    elif drift_model == "fulldrift":
        # ω_κ from Ky, ω_∇B from Ly, distinct
        denom = Omega - 2.0 * Okk * nu * nu - OBB * mu
    elif drift_model == "curvature_gradBeqcurv":
        # Cheng-style: only ν² in denominator
        denom = Omega - 4.0 * Okk * nu * nu
    elif drift_model == "gradB_gradBeqcurv":
        # Only μ in denominator
        denom = Omega - 2.0 * Okk * mu
    else:
        raise ValueError(f"unknown drift_model: {drift_model}")

    integrand = J0sq * num / denom    # (nz+1, Nmu, Nnu)

    weighted = wmu * wnu * integrand
    integral = jnp.sum(weighted, axis=(1, 2))    # (nz+1,)
    return integral / (p.tau * jnp.sqrt(jnp.pi))


# --- Selector ---------------------------------------------------------

def Q_of(
    Omega: jax.Array,
    p: PlasmaParams,
    geo: FluxTubeGeometry,
    mode: str = "analytic_resonant",
    drift_model: str = "gradBeqcurv",
) -> jax.Array:
    """Dispatch to one of the three Q variants by name."""
    if mode == "fluid":
        return Q_fluid(Omega, p, geo).astype(jnp.complex128)
    elif mode == "analytic_resonant":
        return Q_analytic_resonant(Omega, p, geo)
    elif mode == "numeric_resonant":
        return Q_numeric_resonant(Omega, p, geo, drift_model=drift_model)
    else:
        raise ValueError(f"unknown mode: {mode}")
