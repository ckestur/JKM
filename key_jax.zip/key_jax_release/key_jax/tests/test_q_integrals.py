"""Tests for q_integrals.py — Milestones 5.A through 5.E.

Without Julia reference data yet, these check:
- internal consistency between the three Q variants in their overlap regimes
- analytic limits (large |Ω|, b → 0)
- differentiability
- shape/dtype correctness
"""
from __future__ import annotations

import jax
jax.config.update("jax_enable_x64", True)

import numpy as np
import jax.numpy as jnp

from key_jax.state import FluxTubeGeometry, PlasmaParams
from key_jax import q_integrals as qi
from key_jax import frequencies as fq
from key_jax import stencils


def _make_test_geo(nz=64, n_pol=1):
    """Synthetic s-α-like geometry for unit tests.

    Circular tokamak at high shear — analytic forms:
        g^yy = 1 + ŝ²θ²
        Ky   = -cos(θ) - ŝθ sin(θ)   (bad curvature at θ=0)
        B    = 1 / (1 + ε cos(θ)) ≈ 1 (large aspect ratio)
        J    = 1
        Ly   = Ky (the gradB=curv approximation makes them equal)
    """
    theta = np.asarray(stencils.grid_theta(nz, n_pol))
    shat = 0.8
    eps = 0.18  # inverse aspect
    B = 1.0 / (1.0 + eps * np.cos(theta))
    gxx = np.ones_like(theta)
    gxy = shat * theta
    gyy = 1.0 + (shat * theta)**2
    J = np.ones_like(theta) / B    # standard s-α flux-tube Jacobian
    Ky = -(np.cos(theta) + shat * theta * np.sin(theta))
    Ly = Ky.copy()
    dBdz = -eps * np.sin(theta) * B**2

    return FluxTubeGeometry(
        theta=jnp.asarray(theta), B=jnp.asarray(B),
        gxx=jnp.asarray(gxx), gxy=jnp.asarray(gxy), gyy=jnp.asarray(gyy),
        J=jnp.asarray(J), Ly=jnp.asarray(Ly), Ky=jnp.asarray(Ky),
        dBdz=jnp.asarray(dBdz),
        q=1.4, shat=shat, major=3.0, minor=0.54,
        Lref=3.0, n_pol=n_pol, B_ref=1.0,
        dpdx=0.0, nz0=nz,
    )


def _make_test_params(beta=0.005, kyrho=0.1):
    return PlasmaParams(
        beta=beta, tau=1.0, kyrho=kyrho,
        omti=10.0, omte=10.0, omn=1.0,
    )


def test_milestone_5A_Q_fluid_shape_and_dtype():
    """Q_fluid returns a (nz+1,) complex array for any Ω."""
    geo = _make_test_geo(nz=64)
    p = _make_test_params()
    for Omega in [1.0+0.0j, 0.5+0.1j, -0.3-0.2j, 2.0+1.5j]:
        Q = qi.Q_fluid(Omega, p, geo)
        assert Q.shape == (65,)
        assert Q.dtype == jnp.complex128
        assert jnp.all(jnp.isfinite(Q))
    print("  Q_fluid shape/dtype OK for various Ω")


def test_milestone_5B_Q_cheng_shape_and_finiteness():
    """Q_cheng (no hybrid) finite at most Ω, NaN allowed at Ω→0."""
    geo = _make_test_geo(nz=64)
    p = _make_test_params()
    for Omega in [0.5+0.1j, 1.0+0.5j, -0.3+0.05j, 2.0+0.3j]:
        Q = qi.Q_cheng(Omega, p, geo)
        n_finite = int(jnp.sum(jnp.isfinite(Q.real) & jnp.isfinite(Q.imag)))
        print(f"  Ω={Omega}: {n_finite}/{Q.size} finite Q_cheng entries")
        # Allow some near-zero curvature points to fail; majority should be finite
        assert n_finite >= Q.size * 0.5


def test_milestone_5B_Q_analytic_resonant_uses_hybrid():
    """The hybrid Q_analytic_resonant should be finite everywhere."""
    geo = _make_test_geo(nz=64)
    p = _make_test_params()
    for Omega in [0.5+0.1j, 1.0+0.5j, -0.3+0.05j, 2.0+0.3j]:
        Q = qi.Q_analytic_resonant(Omega, p, geo)
        assert jnp.all(jnp.isfinite(Q.real) & jnp.isfinite(Q.imag)), \
            f"Q_analytic_resonant has NaN/Inf at Ω={Omega}"
    print("  Q_analytic_resonant finite everywhere via hybrid mask")


def test_milestone_5C_Q_numeric_resonant_finite_and_differentiable():
    """Q_numeric_resonant returns finite, differentiable values."""
    geo = _make_test_geo(nz=32)
    p = _make_test_params()
    Omega = 1.0 + 0.3j
    Q = qi.Q_numeric_resonant(Omega, p, geo)
    assert Q.shape == (33,)
    assert jnp.all(jnp.isfinite(Q.real) & jnp.isfinite(Q.imag)), \
        f"Q_numeric_resonant has NaN/Inf"
    print(f"  Q_numeric_resonant Ω={Omega}: |Q|_max = {float(jnp.abs(Q).max()):.3e}")


def test_milestone_5_consistency_strong_drive_limit():
    """In the strongly-driven limit |Ω| >> Ω_κ EVERYWHERE on the field line,
    all three Q's should agree.

    This is Mulholland's eq. 4.29 derivation: Q_resonant -> Q_fluid as
    Ω_Di / |Ω| -> 0. Use Ω large enough that ξ ≫ 1 across all θ.
    """
    geo = _make_test_geo(nz=64)
    p = _make_test_params(beta=0.001, kyrho=0.01)  # weak FLR
    Omega = 100.0 + 10.0j  # |Ω| >> max|4 Ω_κ|

    Qf = qi.Q_fluid(Omega, p, geo).astype(jnp.complex128)
    Qa = qi.Q_analytic_resonant(Omega, p, geo)
    Qn = qi.Q_numeric_resonant(Omega, p, geo)

    diff_fa = float(jnp.abs(Qf - Qa).max() / jnp.abs(Qf).max())
    diff_fn = float(jnp.abs(Qf - Qn).max() / jnp.abs(Qf).max())
    print(f"  large-Ω limit: |Q_f - Q_analytic|/|Q_f| = {diff_fa:.3e}")
    print(f"  large-Ω limit: |Q_f - Q_numeric|/|Q_f|  = {diff_fn:.3e}")
    # Should agree to within a few percent at this Ω
    assert diff_fa < 0.05, "Q_analytic should converge to Q_fluid at strong drive"
    assert diff_fn < 0.05, "Q_numeric should converge to Q_fluid at strong drive"


def test_milestone_5_cheng_matches_numeric_curvature_model():
    """Q_cheng (Mulholland eq. 4.46) should equal Q_numeric with the
    'curvature_gradBeqcurv' drift model (KEY line 203) — they are the
    same integral, with Q_cheng evaluated analytically via Z(ξ) and
    Q_numeric via 2D Gauss-Laguerre × Gauss-Hermite.

    Subtlety: Gauss-Hermite at N=31 has node-spacing ~0.4 near zero. When
    |Im ξ| << 0.4 (which happens at θ where Ky has the WRONG sign for the
    sign of Ω_r/Ω_κ to put ξ in UHP near real axis), the v∥ pole sits in
    the un-resolved region and Q_numeric is inaccurate.

    Q_cheng (analytic) is correct everywhere; Q_numeric is correct only
    in the well-resolved regions. We test agreement at θ where the
    bad-curvature drive lives (Ky < 0, |Im ξ| > 0.5) — this is where the
    KBM physics actually happens.
    """
    geo = _make_test_geo(nz=32)
    p = _make_test_params(beta=0.001, kyrho=0.01)
    # Work only at indices near θ=0 (bad curvature for our test geometry)
    # where Ky < 0 and the pole is well-resolved
    Ky = np.asarray(geo.Ky)
    theta = np.asarray(geo.theta)
    bad_curv_mask = (Ky < -0.3) & (np.abs(theta) < 1.0)
    print(f"  bad-curv mask: {int(bad_curv_mask.sum())} of {len(Ky)} theta points")

    cases = [
        (0.5+0.5j, 0.10),
        (1.0+0.3j, 0.10),
        (5.0+1.0j, 0.01),
        (30.0+3.0j, 0.001),
    ]
    for Omega, tol in cases:
        Q_c = np.asarray(qi.Q_cheng(Omega, p, geo))
        Q_n = np.asarray(qi.Q_numeric_resonant(Omega, p, geo,
                                     drift_model="curvature_gradBeqcurv"))
        diff = np.abs(Q_c - Q_n)[bad_curv_mask]
        rel = diff.max() / np.abs(Q_n[bad_curv_mask]).max()
        print(f"  Ω={Omega} (bad-curv only): rel diff = {rel:.3e} (tol {tol})")
        assert rel < tol, f"Q_cheng vs Q_numeric inconsistent at Ω={Omega}"


def test_milestone_5D_jax_grad_through_Q():
    """jax.grad through Q_fluid w.r.t. β returns finite values."""
    geo = _make_test_geo(nz=32)

    def loss_fluid(beta):
        p = PlasmaParams(beta=beta, tau=1.0, kyrho=0.1,
                         omti=10.0, omte=10.0, omn=1.0)
        Q = qi.Q_fluid(1.0 + 0.3j, p, geo)
        return jnp.sum(jnp.abs(Q)**2)
    g = jax.grad(loss_fluid)(0.005)
    assert jnp.isfinite(g)
    print(f"  d(|Q_fluid|²)/dβ at β=0.005 = {float(g):.3e}")

    def loss_resonant(beta):
        p = PlasmaParams(beta=beta, tau=1.0, kyrho=0.1,
                         omti=10.0, omte=10.0, omn=1.0)
        Q = qi.Q_analytic_resonant(1.0 + 0.3j, p, geo)
        return jnp.sum(jnp.abs(Q)**2)
    g2 = jax.grad(loss_resonant)(0.005)
    assert jnp.isfinite(g2)
    print(f"  d(|Q_analytic|²)/dβ at β=0.005 = {float(g2):.3e}")

    def loss_numeric(beta):
        p = PlasmaParams(beta=beta, tau=1.0, kyrho=0.1,
                         omti=10.0, omte=10.0, omn=1.0)
        Q = qi.Q_numeric_resonant(1.0 + 0.3j, p, geo)
        return jnp.sum(jnp.abs(Q)**2)
    g3 = jax.grad(loss_numeric)(0.005)
    assert jnp.isfinite(g3)
    print(f"  d(|Q_numeric|²)/dβ at β=0.005 = {float(g3):.3e}")


def test_milestone_5E_drift_models_distinct():
    """Different drift_model values give different Q_numeric.

    Important infrastructure for §10.3 research direction.
    """
    geo = _make_test_geo(nz=32)
    p = _make_test_params()
    Omega = 1.0 + 0.3j

    Q_default = qi.Q_numeric_resonant(Omega, p, geo, drift_model="gradBeqcurv")
    Q_curv    = qi.Q_numeric_resonant(Omega, p, geo, drift_model="curveqgradB")
    Q_full    = qi.Q_numeric_resonant(Omega, p, geo, drift_model="fulldrift")
    Q_only_n2 = qi.Q_numeric_resonant(Omega, p, geo, drift_model="curvature_gradBeqcurv")

    diffs = [
        ("default vs curv", float(jnp.abs(Q_default - Q_curv).max() / jnp.abs(Q_default).max())),
        ("default vs full", float(jnp.abs(Q_default - Q_full).max() / jnp.abs(Q_default).max())),
        ("default vs only_n²", float(jnp.abs(Q_default - Q_only_n2).max() / jnp.abs(Q_default).max())),
    ]
    for name, d in diffs:
        print(f"  {name}: relative diff = {d:.3e}")
    # In our test geometry Ly == Ky so default and curveqgradB and fulldrift agree.
    # only_n² differs because it drops the μ term.
    assert diffs[2][1] > 0.01, "only_n² should differ from default"


if __name__ == "__main__":
    print("--- 5.A: Q_fluid shape and dtype ---")
    test_milestone_5A_Q_fluid_shape_and_dtype()
    print("--- 5.B: Q_cheng / Q_analytic_resonant finiteness ---")
    test_milestone_5B_Q_cheng_shape_and_finiteness()
    test_milestone_5B_Q_analytic_resonant_uses_hybrid()
    print("--- 5.C: Q_numeric_resonant ---")
    test_milestone_5C_Q_numeric_resonant_finite_and_differentiable()
    print("--- 5.X: agreement in strong-drive limit ---")
    test_milestone_5_consistency_strong_drive_limit()
    print("--- 5.Y: Q_cheng vs Q_numeric(curvature) internal consistency ---")
    test_milestone_5_cheng_matches_numeric_curvature_model()
    print("--- 5.D: differentiability ---")
    test_milestone_5D_jax_grad_through_Q()
    print("--- 5.E: drift-model variants distinct ---")
    test_milestone_5E_drift_models_distinct()
    print("\n*** All Q-integral tests passed ***")
