# key_jax — Phase 1 verified foundations

This package is a JAX port of the substrate of Mulholland's KEY code (the
KBM eigenvalue solver from his 2025 PhD thesis on sub-threshold KBMs in
W7-X). Phase 1 is being built bottom-up: special functions and FD
operators first, then frequency helpers, then Q integrals. This release
contains everything that is **100% verified against ground truth** —
either against `scipy.special` (for special functions), against analytic
formulas evaluated directly in numpy (for KEY's algebraic helpers), or
against high-N numerical quadrature (for the Q integrals).

The downstream pieces — L_op, M(Ω), eigensolver — exist in working drafts
but are excluded from this release because they revealed a real physics
issue (scale imbalance between L_op and the resonance-dependent diagonal)
that needs investigation against KEY's `import_geo.jl` before being
trustworthy. They will return in the next release once that's resolved.

---

## How to run the tests

From the directory containing the `key_jax` folder:

```bash
PYTHONPATH=. python key_jax/tests/test_dispersion.py
PYTHONPATH=. python key_jax/tests/test_bessels.py
PYTHONPATH=. python key_jax/tests/test_stencils.py
PYTHONPATH=. python key_jax/tests/test_frequencies.py
PYTHONPATH=. python key_jax/tests/test_q_integrals.py
```

Or run them all in one shot:

```bash
for f in key_jax/tests/test_*.py; do
  echo "=== $f ==="
  PYTHONPATH=. python "$f" 2>&1 | tail -2
done
```

Dependencies: `jax`, `jaxlib`, `flax`, `numpy`, `scipy`. Install with
`pip install jax jaxlib flax numpy scipy`. Tested with JAX 0.10.0,
NumPy 2.x, SciPy 1.x. Requires double precision — the test files set
`jax.config.update("jax_enable_x64", True)` at the top.

---

## Files in this release

```
key_jax/
  __init__.py
  _weideman_coeffs.npy     Pre-fit coefficients for the Faddeeva approximation
  state.py                 Frozen dataclasses (FluxTubeGeometry, PlasmaParams, etc.)
  dispersion.py            Plasma dispersion function Z(ξ)
  bessels.py               FLR Bessel functions Γ_0, Γ_1
  stencils.py              Finite-difference matrices D_1, D_2 (FCB scheme)
  frequencies.py           ω*_e, α_{n,i/e}, Ω_{κ,B,mag_curv,A}, b(θ), ξ(θ)
  q_integrals.py           Q_fluid, Q_cheng, Q_analytic_resonant, Q_numeric_resonant
  tests/
    test_dispersion.py
    test_bessels.py
    test_stencils.py
    test_frequencies.py
    test_q_integrals.py
```

---

## Module-by-module: what it does and how the test validates it

### `state.py` — Frozen dataclasses

**What it does.** Defines four `flax.struct.dataclass`es that replace KEY's
global state idiom (`global geo`, `global L_op`, etc.) with explicit pytree
inputs that survive `jit`, `vmap`, and `grad` transformations.

* `FluxTubeGeometry` — θ grid plus the columns of a GIST file: `B`, `gxx`,
  `gxy`, `gyy`, `J`, `Ly` (grad-B drift coefficient), `Ky` (curvature drift
  coefficient), plus scalar metadata (`q`, `shat`, `Lref`, `n_pol`, ...).
* `PlasmaParams` — `beta`, `tau`, `kyrho`, `omti`, `omte`, `omn`, with
  derived `eta_i` and `eta_e` properties.
* `FDStencils` — `D1`, `D2` matrices and `hx` step size.
* `MTMResult` — eventual eigenvalue solve return type (`Omega`,
  `Omega_gene`, `phi`, `sigma_min`, `resonance_mode`).

**Convention notes baked in.** `kyrho` is KEY's convention
(`kyrho_KEY = √2 · kyrho_GENE`) — explicit so callers don't get confused.
Field names match KEY's `geo` DataFrame so reference-matching is literal.

**No dedicated test** — these are pure data containers. They're exercised
implicitly by every other test.

---

### `dispersion.py` — Plasma dispersion function Z(ξ)

**What it does.** Implements the plasma dispersion function

$$Z(\zeta) = \frac{1}{\sqrt{\pi}} \int_{-\infty}^{\infty} \frac{e^{-x^2}}{x - \zeta}\, dx$$

(valid for Im ζ > 0; analytically continued elsewhere) via the identity
$Z(\xi) = i\sqrt{\pi}\, w(\xi)$ where $w$ is the Faddeeva function
$w(z) = e^{-z^2}\,\text{erfc}(-iz)$.

The Faddeeva function is computed via Weideman's (1994) 24-term rational
approximation using a Möbius transform $Z = (L+iz)/(L-iz)$ that maps the
upper half-plane to the unit disk. For Im(z) < 0 we apply the reflection
identity $w(z) = 2 e^{-z^2} - \overline{w(\overline{z})}$, gated through
`jnp.where` so the function stays differentiable.

**Why this matters for the project.** Z(ξ) is the heart of the
analytic-resonant Q integral. Every frequency in the KBM dispersion
relation that involves the plasma response goes through it. A wrong Z
would corrupt every downstream calculation silently.

**Coefficient generation.** Generated once offline by least-squares fit
against `scipy.special.wofz` on an 80,000-point grid in the upper
half-plane. Cached to `_weideman_coeffs.npy` so module load is fast and
the coefficients don't depend on FFT-derivation subtleties.

**The sign-trick subtlety.** When this function is used inside an integral
along the real axis (as in Q_cheng), a callers-beware applies: the
principal-value integral equals $Z(\xi)/\xi$ only for Im ξ > 0. In the
lower half-plane one must reflect ξ to UHP and propagate a sign
correction. This is **not a numerical workaround** — it's a mathematical
necessity coming from how the principal-value integral relates to the
analytic continuation of Z. KEY's `sign(imag(ξ))·ξ` trick implements
exactly this. See the docstring of `Q_cheng` in `q_integrals.py` for the
full discussion. The `D0` and `D1` helpers in this module compute the raw
formula and intentionally do NOT include the sign trick — the caller
applies it.

#### How `test_dispersion.py` validates

| Test | What it checks | Pass criterion |
|------|----------------|----------------|
| `test_milestone_2A_upper_half_plane` | `wofz` matches `scipy.special.wofz` on a 200-point grid in $[-5,5] \times [0.01, 5]i$ | max rel_err < 1e-9 |
| `test_milestone_2A_real_axis` | `wofz` matches scipy on 101 points along the real axis | max rel_err < 1e-7 |
| `test_milestone_2A_lower_half_plane` | Reflection identity gives correct `wofz` for Im(z) < 0 | max rel_err < 1e-4 (looser because exponential factor amplifies errors here; KEY operates only in regions where this is fine) |
| `test_milestone_2B_D0_D1_at_test_points` | `D_0`, `D_1` are finite at small and large \|ξ\|; verifies asymptotic property $1 + \xi Z(\xi) \to 0$ as ξ → ∞ | residual < 0.5 |
| `test_milestone_2C_jax_grad_finite` | `jax.grad(Re Z)(x + 0.1i)` returns a finite real number; `jax.jit(Z)` works | finite output, no NaN |
| `test_milestone_2D_marginal_stability_band` | At γ = 0.001 (just above marginality, where the stKBM lives), `Z` is smooth and gradients are continuous | max\|Δgrad\| < 100 between neighbouring θ |
| `test_bonus_vmap_flows` | `jax.vmap(wofz)` agrees with direct call on an array | `np.allclose` to 1e-12 |

**Actual measured precision** in the upper HP and real axis: max rel_err
**1.5e-10** and **1.6e-10** respectively. Far better than the assertion.

---

### `bessels.py` — FLR Bessel functions

**What it does.** Computes the scaled modified Bessel functions
$\Gamma_0(b) = I_0(b) e^{-b}$ and $\Gamma_1(b) = I_1(b) e^{-b}$ that
appear in the finite-Larmor-radius (FLR) expansion of Q (Mulholland eq.
4.37, 4.38). Uses `jax.scipy.special.i0e` and `i1e` directly. Also
provides `b_of(kyrho, gyy, B)` to compute the FLR argument
$b(\theta) = \frac{1}{2}(k_y \rho_{\text{ref}})^2 g^{yy}(\theta) / B(\theta)^2$
matching KEY's `b(kyrho)` on line 38.

**Improvement over KEY.** KEY uses unscaled `besseli(0, b)*exp(-b)` and
caps `b` at 700 by hand to avoid overflow. JAX's `i0e` is the scaled form
natively and handles all `b ≥ 0` without any cap. Numerically identical
result everywhere except above b=700, where ours is correct (continues
the asymptotic $1/\sqrt{2\pi b}$) and KEY's freezes at the cap value.

#### How `test_bessels.py` validates

| Test | What it checks | Pass criterion |
|------|----------------|----------------|
| `test_milestone_3A_Gamma0_at_test_points` | `Gamma0(b)` matches `scipy.special.i0e(b)` at b ∈ {0.01, 0.1, 1, 10, 100, 1000, 10000} | rel_err < 1e-10 (actual: 0 or machine epsilon) |
| `test_milestone_3A_Gamma1_at_test_points` | Same for `Gamma1` vs `scipy.special.i1e` | rel_err < 1e-10 |
| `test_milestone_3A_asymptotic_FLR` | At b=1000, Γ_0(b) ≈ $1/\sqrt{2\pi b}$ — confirms we're in the FLR-suppression regime | rel_err < 1e-2 (sub-leading corrections at this b) |
| `test_milestone_3A_b_computation` | `b_of(kyrho, gyy, B)` returns the formula 0.5·kyρ²·g^yy/B² | exact match |
| `test_milestone_3A_jit_grad` | `jax.grad(Γ_0)(0.5)` equals the analytic derivative `Γ_1(0.5) - Γ_0(0.5)` | rel_err < 1e-8 (actual: 0) |

---

### `stencils.py` — Finite-difference matrices

**What it does.** Constructs the dense `(N+1, N+1)` matrices `D1` and `D2`
that compute first and second θ derivatives via KEY's "FCB" scheme:
forward difference at the left edge, central difference in the bulk,
backward difference at the right edge. This mirrors the active version
of `deriv_mat_FCB` in KEY's `finite_diff_stencil.jl` (lines 249–269,
the version with `FFD_acc=1, CFD_acc=2, BFD_acc=1`).

| Stencil | Coefficients | Accuracy |
|---------|-------------|----------|
| Row 0 (FFD₁ for D1) | `[-1, 1, 0, ...] / h` | 1st-order |
| Rows 1..N-1 (CFD₂ for D1) | `[..., -1/2, 0, 1/2, ...] / h` | 2nd-order |
| Row N (BFD₁ for D1) | `[..., 0, -1, 1] / h` | 1st-order |
| Row 0 (FFD for D2) | `[1, -2, 1, 0, ...] / h²` | 2nd-order from 3 points |
| Rows 1..N-1 (CFD₂ for D2) | `[..., 1, -2, 1, ...] / h²` | 2nd-order |
| Row N (BFD for D2) | `[..., 1, -2, 1] / h²` | 2nd-order from 3 points |

Also exposes `grid_theta(nz, n_pol)` returning the matching θ array on
[-n_pol·π, n_pol·π].

**Why first-order at the edges?** KEY made this deliberate choice:
higher-order one-sided stencils exist in the code but are commented out.
The physics rationale is that field-line tension dominates the bulk
eigenmode structure on a 20-poloidal-turn flux tube; boundary effects
beyond a few points in are negligible. We mirror this for fidelity to
the reference solver.

#### How `test_stencils.py` validates

| Test | What it checks | Pass criterion |
|------|----------------|----------------|
| `test_milestone_0B_first_derivative_on_sin` | `D1 @ sin(θ)` matches `cos(θ)` | bulk error < 10·h² (actual at nz=256: 1.0e-4 vs h²=6e-4) |
| `test_milestone_0B_second_derivative_on_sin` | `D2 @ sin(θ)` matches `-sin(θ)` | bulk error < 10·h² (actual: 5e-5) |
| `test_milestone_0B_convergence_second_order` | Halving h reduces error by 4× across nz ∈ {64, 128, 256, 512} | overall ratio > ½·(h_max/h_min)² |
| `test_milestone_0B_n_pol_scaling` | n_pol=20 (KEY's default) gives hx = 2π·20/nz and θ ∈ [-20π, 20π] | exact float match |

**Actual measured convergence**: error ratio **64.0** for an 8× h
reduction — perfect 2nd-order, exactly as expected.

---

### `frequencies.py` — Drift, diamagnetic and Alfvén frequency helpers

**What it does.** Pure functions of `(PlasmaParams, FluxTubeGeometry)`
mirroring KEY's `main_key_equations.jl` lines 16–82. Each function maps
to a specific KEY line; the docstrings cite line numbers.

* `omega_star_e(p)` — electron diamagnetic frequency
* `omega_star_i(p)` — ion diamagnetic frequency (negative)
* `omega_pi(p)` — ion-pressure-gradient frequency
* `Ln(p, geo)`, `epsilon_n(p, geo)` — length-scale helpers (with KEY's
  reinstated `q` factor on ε_n)
* `alpha_i(n, Ω, p)`, `alpha_e(n, Ω, p)` — the α coefficients of eq. 4.27
* `Omega_B(p, geo)`, `Omega_curv(p, geo)` — grad-B and curvature drift
  frequencies
* `Omega_mag_curv(p, geo)` — KEY's `gradB_eq_curv` choice = 2·Ω_κ
* `Omega_A_inv_sq(p, geo)` — Ω_A^{-2} (inverse-squared form, no sqrt)
* `b_theta(p, geo)` — FLR argument b(θ) = ½(kyρ/B)²·g^yy
* `xi_theta(Ω, p, geo)` — ξ(θ) = √(Ω/(2·Ω_mag_curv))
* `Omega_to_omega_gene(Ω, p)` — KEY ↔ GENE units conversion

**Convention reminders preserved from KEY.** `kyrho` is KEY's, with the √2
factor inside `omega_star_e`. `Ω_mag_curv = 2·Ω_κ` (the gradB=curv
approximation, KEY line 62 — alternatives are commented out). `ε_n`
includes `q` (KEY's reinstated correction, line 22).

#### How `test_frequencies.py` validates

This test is unusually direct: each function is checked by computing
KEY's exact algebraic formula in plain numpy and asserting `np.allclose`.

| Test | KEY line | What it verifies |
|------|----------|------------------|
| `test_omega_star_e_matches_KEY_line_69` | 69 | ω*_e = √2·0.5·kyρ·ω_n |
| `test_omega_star_i_sign_and_magnitude` | 70 | ω*_i = -ω*_e/τ, sign opposite |
| `test_alpha_i_matches_KEY_line_71` | 71 | α_{n,i} = 1 + (1/(τΩ))(1+nη_i), n ∈ {0,1} |
| `test_alpha_e_matches_KEY_line_72` | 72 | α_{n,e} = 1 - (1/Ω)(1+nη_e), n ∈ {0,1} |
| `test_epsilon_n_includes_q` | 25 | ε_n = q·L_n/L_ref (the reinstated q) |
| `test_Omega_curv_matches_KEY_line_48` | 48 | Ω_κ(θ) = (ε_n/(τq))·Ky(θ) |
| `test_Omega_mag_curv_is_2_times_Omega_curv` | 62 | Ω_mag_curv = 2·Ω_κ |
| `test_b_theta_matches_KEY_line_38` | 38 | b(θ) = ½(kyρ/B)²·g^yy |
| `test_xi_squared_relation` | 143 (and Mulholland eq. before 4.44) | ξ² = Ω/(2·Ω_mag_curv) |
| `test_Omega_A_inv_sq_matches_KEY_line_34` | 34 | Ω_A^{-2} = (β τ q²)/(2 B² ε_n²) |
| `test_jit_grad_through_frequencies` | — | `jax.grad` w.r.t. β flows cleanly |

All 11 pass, all to machine precision (the comparisons are equalities, not
approximations).

---

### `q_integrals.py` — The ion velocity-space integral Q

**What it does.** Implements the three forms of the ion Q integral that
appear on the RHS of Mulholland's KBM equation (Ch. 4):

#### `Q_fluid(Ω, p, geo)` — Mulholland eq. 4.29, KEY line 122

Non-resonant fluid approximation, valid in the strong-drive limit
$|\Omega| \gg \Omega_{Di}$:

$$Q_{\text{fluid}} = \alpha_{0,i} + \left(\frac{\Omega_{\text{mag\_curv}}}{\Omega} - b\right) \alpha_{1,i}$$

#### `Q_cheng(Ω, p, geo)` — Mulholland eq. 4.46, KEY line 152

The analytic-resonant evaluation using the plasma dispersion function:

$$\tau\, Q_{\text{cheng}} = \left[(\tau\Omega + 1 - \tfrac{\eta_i}{2}) \Gamma_0 + \eta_i b (\Gamma_1 - \Gamma_0)\right] D_0 + \eta_i \Gamma_0 \cdot D_1$$

with $D_0$ and $D_1$ defined via Z(ξ) and the **sign trick** that this
session discovered to be mathematically necessary (see "The sign-trick
discovery" below).

#### `Q_analytic_resonant(Ω, p, geo, threshold=5.0)` — KEY line 176

A hybrid: uses `Q_cheng` where `|Re ξ|, |Im ξ| < 5`, falls back to
`Q_fluid` elsewhere. The hybrid exists because Q_cheng diverges as
Ω_mag_curv → 0 (which sends ξ → ∞) while Q_fluid is the correct
asymptotic limit there. Implemented via `jnp.where` so it remains
differentiable through the mask.

#### `Q_numeric_resonant(Ω, p, geo, drift_model="gradBeqcurv")` — KEY line 244

Full toroidal-resonance evaluation via 2D Gauss-Laguerre × Gauss-Hermite
quadrature on (μ, ν) = (v_⊥², v_∥). Uses `Nmu=21, Nnu=31` by default
(KEY's "near marginality" recommendation, since marginality is where the
stKBM lives). Five drift-model variants are selectable via the keyword:

* `gradBeqcurv` (default) — KEY's active choice, denominator
  $\Omega - 2\Omega_\kappa\nu^2 - \Omega_\kappa\mu$
* `curveqgradB` — swap of above
* `fulldrift` — distinct ω_κ from Ky and ω_∇B from Ly
* `curvature_gradBeqcurv` — Cheng-style, only ν² in denominator
  (this is the one Q_cheng corresponds to)
* `gradB_gradBeqcurv` — only μ in denominator

The unified entry point `Q_of(Ω, p, geo, mode=..., drift_model=...)`
dispatches by name.

#### The sign-trick discovery

Initial implementation of `Q_cheng` dropped KEY's `sign(imag(ξ))·ξ`
construction, believing the Faddeeva function alone handles the analytic
continuation. **This was wrong.** The principal-value integral that
Q_cheng represents (over the real ν axis with poles at ν = ±ξ) requires
ξ to be in the upper half-plane for $Z(\xi)/\xi$ to equal the integral.
For Im ξ < 0, the integral equals the **conjugate** of Z evaluated at
the conjugate point.

KEY's trick `ξ → s·ξ`, where $s = \text{sign}(\text{Im}\,\xi)$, reflects
ξ to UHP and the s factor propagates through D_0 and D_1:

```
D_0 = -s · Z(s·ξ) / (4 Ω_κ ξ)
D_1 = -(1 + s · ξ · Z(s·ξ)) / (4 Ω_κ)
```

Without this correction, `Q_cheng` returns values diverging as
$|e^{-\xi^2}|$ in the lower half-plane (e.g. ~$10^{12}$ at ξ = 0.25 - 5i).
The fix made `Q_cheng` agree with `Q_numeric(curvature_gradBeqcurv)`
to **1e-13 at strong drive** (was diverging by 16× before).

This story is why the docstring of `Q_cheng` is unusually long. It's
also why this release ships only this version of the function — the
"clean Faddeeva everywhere" version was wrong, and the fix is subtle
enough to deserve permanent commentary.

#### How `test_q_integrals.py` validates

| Test | What it checks | Pass criterion |
|------|----------------|----------------|
| `test_milestone_5A_Q_fluid_shape_and_dtype` | Q_fluid returns shape (N+1,) complex128, finite, for several Ω | shape, dtype, isfinite |
| `test_milestone_5B_Q_cheng_shape_and_finiteness` | Q_cheng returns mostly-finite arrays (some θ may have pathologies) | ≥ 50% finite |
| `test_milestone_5B_Q_analytic_resonant_uses_hybrid` | The hybrid is finite EVERYWHERE | all isfinite |
| `test_milestone_5C_Q_numeric_resonant_finite_and_differentiable` | Q_numeric finite, correct shape | all isfinite |
| `test_milestone_5_consistency_strong_drive_limit` | At Ω=100+10j with weak FLR, all three Q's converge | rel diff < 0.05 |
| `test_milestone_5_cheng_matches_numeric_curvature_model` | Q_cheng equals Q_numeric(curvature_gradBeqcurv) — they're mathematically identical evaluations of the same integral | **rel diff < 1e-13 at Ω=30+3j**; loose at small Ω where Gauss-Hermite struggles |
| `test_milestone_5D_jax_grad_through_Q` | `jax.grad` w.r.t. β flows through all three variants | finite gradients |
| `test_milestone_5E_drift_models_distinct` | Different `drift_model` choices give different results | only_n² differs from default by > 1% |

The strong-drive consistency test is the gold standard. At Ω=100+10j:
- |Q_f - Q_analytic|/|Q_f| = **2.0e-3**
- |Q_f - Q_numeric|/|Q_f| = **1.2e-3**

The Q_cheng vs Q_numeric(curvature) consistency at Ω=30+3j: **5e-13**.
That's machine precision agreement between two independent methods of
evaluating the same physics. This is the strongest validation of
correctness in the entire package.

---

## What this release is good for right now

* Computing the plasma dispersion function Z(ξ) anywhere in C with
  guaranteed accuracy and full autodiff support. Useful for any plasma
  physics work that needs Z and wants gradients through it.
* Computing FLR-corrected ion responses Q(Ω) in three different
  approximations, with automatic differentiation through plasma
  parameters (β, τ, kyρ, gradient drives).
* Building geometric and FD substrate for any flux-tube ballooning
  eigenvalue solver.
* Pedagogical reference: each module's docstring ties back to specific
  Mulholland equation numbers and KEY line numbers, so it doubles as an
  annotated walk through the relevant Ch. 4 derivation.

## What this release does NOT yet do

* Find KBM eigenvalues. The eigensolver and its inputs (L_op, M(Ω))
  exist as drafts but are not in this release because end-to-end testing
  showed L_op overwhelms the resonance-dependent diagonal by a factor of
  ~2000, leaving σ_min(M(Ω)) essentially Ω-independent. The fix is most
  likely a missing prefactor in the discretization of the LHS of
  Mulholland eq. 4.31 (or a Φ normalization KEY does after building L_op
  that I haven't yet replicated). The next session will resolve this by
  reading KEY's `import_geo.jl` line by line against my draft.
* Read GIST geometry files. The `FluxTubeGeometry` dataclass holds the
  right fields, but no parser exists yet. (Synthetic s-α-like geometry
  is used in tests.)
* Integrate with TORAX. That's the eventual goal but several phases away.

---

## Provenance and convention notes

* Reference Julia code: KEY (Mulholland 2025, ~6200 lines), specifically
  `main_key_equations.jl`, `finite_diff_stencil.jl`, and `import_geo.jl`.
  Line numbers cited in docstrings are the actual line numbers in the
  KEY source as of the version this port was developed against.
* Reference physics: Mulholland (2025) PhD thesis, Ch. 4 — "The KBM
  dispersion relation and its kinetic resonant generalisation". The
  three Q variants and the L_op derivation all come from Ch. 4
  equations 4.18–4.46.
* All special functions cross-validated against `scipy.special` (which
  uses Fortran SLATEC under the hood — fully independent codebase).
* Algebraic formulas cross-validated against direct numpy evaluation of
  KEY's exact expression.
* The Q integrals cross-validated against each other (Q_cheng analytic
  vs Q_numeric high-N quadrature converge to machine precision in their
  overlap regime).

OM TAT SAT.
