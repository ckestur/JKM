"""Finite-difference stencil matrices for key_jax.

Mirrors KEY's `deriv_mat_FCB` (default active version, finite_diff_stencil.jl
lines 249-269):

    Row 1 (i=0):         Forward difference, accuracy 1
    Row 2..N-1:          Central difference, accuracy 2
    Last row (i=N):      Backward difference, accuracy 1

These matrices operate on a field discretized on (N+1) uniformly-spaced
theta points in [-n_pol*pi, n_pol*pi]. Grid spacing hx = 2*pi*n_pol / N.

The first-order boundary scheme is a deliberate KEY choice: higher-order
edge schemes are available in the code but commented out. The physics
reason is that field-line tension (||d^2 Phi/dtheta^2||) in the KBM
equation is dominated by the bulk eigenmode structure, and boundary
effects beyond a few points in are negligible — the flux tube is already
20 poloidal turns long.

All construction is done in numpy for the dense matrix, then converted
to jnp. The matrices are constants and jit/vmap-clean.
"""
from __future__ import annotations

import jax.numpy as jnp
import numpy as np

from key_jax.state import FDStencils


def build_stencils(nz: int, n_pol: int = 1) -> FDStencils:
    """Construct D1, D2 matrices (shape (nz+1, nz+1)) for the FCB scheme.

    Parameters
    ----------
    nz : int
        Number of grid intervals; output matrices are (nz+1) x (nz+1).
    n_pol : int
        Number of poloidal turns; determines theta range = [-n_pol*pi, n_pol*pi].

    Returns
    -------
    FDStencils with D1, D2 as jnp.float64 arrays.
    """
    N = nz + 1
    hx = 2.0 * np.pi * n_pol / nz  # grid spacing

    # First-derivative matrix
    D1 = np.zeros((N, N))
    # Row 0: forward difference, first order: f'[0] = (f[1] - f[0]) / h
    D1[0, 0] = -1.0 / hx
    D1[0, 1] = 1.0 / hx
    # Rows 1..N-2: central difference, second order: f'[i] = (f[i+1] - f[i-1]) / (2h)
    for i in range(1, N - 1):
        D1[i, i - 1] = -0.5 / hx
        D1[i, i + 1] = 0.5 / hx
    # Row N-1: backward difference, first order: f'[N-1] = (f[N-1] - f[N-2]) / h
    D1[N - 1, N - 2] = -1.0 / hx
    D1[N - 1, N - 1] = 1.0 / hx

    # Second-derivative matrix
    D2 = np.zeros((N, N))
    inv_hx2 = 1.0 / (hx * hx)
    # Row 0: forward, 3-point: f''[0] = (f[0] - 2 f[1] + f[2]) / h^2
    D2[0, 0] = 1.0 * inv_hx2
    D2[0, 1] = -2.0 * inv_hx2
    D2[0, 2] = 1.0 * inv_hx2
    # Rows 1..N-2: central: f''[i] = (f[i-1] - 2 f[i] + f[i+1]) / h^2
    for i in range(1, N - 1):
        D2[i, i - 1] = 1.0 * inv_hx2
        D2[i, i]     = -2.0 * inv_hx2
        D2[i, i + 1] = 1.0 * inv_hx2
    # Row N-1: backward, 3-point: f''[N-1] = (f[N-3] - 2 f[N-2] + f[N-1]) / h^2
    D2[N - 1, N - 3] = 1.0 * inv_hx2
    D2[N - 1, N - 2] = -2.0 * inv_hx2
    D2[N - 1, N - 1] = 1.0 * inv_hx2

    return FDStencils(
        D1=jnp.asarray(D1, dtype=jnp.float64),
        D2=jnp.asarray(D2, dtype=jnp.float64),
        hx=hx,
    )


def grid_theta(nz: int, n_pol: int = 1) -> jnp.ndarray:
    """Return the theta grid matching build_stencils."""
    return jnp.linspace(-np.pi * n_pol, np.pi * n_pol, nz + 1)
