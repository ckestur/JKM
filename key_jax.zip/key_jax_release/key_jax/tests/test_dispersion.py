"""Tests for dispersion.py — Milestones 2.A, 2.B, 2.C, 2.D.

Run with: python -m pytest tests/test_dispersion.py -v
Or directly: python tests/test_dispersion.py
"""
from __future__ import annotations

import jax
jax.config.update("jax_enable_x64", True)

import numpy as np
import scipy.special
import jax.numpy as jnp

from key_jax import dispersion


def test_milestone_2A_upper_half_plane():
    """Z(xi) matches scipy.special.wofz * i*sqrt(pi) to 1e-10 on a
    200-point grid in the upper half-plane, xi in [-5,5] x [0.01,5]i.

    This is the single most important unit test in the port.
    """
    xs = np.linspace(-5, 5, 20)
    ys = np.linspace(0.01, 5, 10)
    XX, YY = np.meshgrid(xs, ys)
    xi_grid = (XX + 1j*YY).flatten()

    w_jax = np.asarray(dispersion.wofz(xi_grid))
    w_sci = scipy.special.wofz(xi_grid)

    rel_err = np.abs(w_jax - w_sci) / np.maximum(np.abs(w_sci), 1e-12)
    worst = rel_err.max()
    median = np.median(rel_err)
    print(f"  [2.A upper HP] max rel_err = {worst:.2e}, median = {median:.2e}")
    assert worst < 1e-9, f"Upper-HP accuracy failed: worst rel_err = {worst:.2e}"


def test_milestone_2A_real_axis():
    """Real-axis accuracy separately — this is where Weideman is weakest
    and where the stKBM lives (marginal stability)."""
    xs = np.linspace(-5, 5, 101)
    xi_real = xs + 0j

    w_jax = np.asarray(dispersion.wofz(xi_real))
    w_sci = scipy.special.wofz(xi_real)

    rel_err = np.abs(w_jax - w_sci) / np.maximum(np.abs(w_sci), 1e-12)
    worst = rel_err.max()
    median = np.median(rel_err)
    print(f"  [2.A real axis] max rel_err = {worst:.2e}, median = {median:.2e}")
    # Real axis has 1e-8 published accuracy; permit 1e-7 for worst case
    assert worst < 1e-7, f"Real-axis accuracy failed: worst rel_err = {worst:.2e}"


def test_milestone_2A_lower_half_plane():
    """Reflection trick for Im(z) < 0."""
    xs = np.linspace(-5, 5, 20)
    ys = np.linspace(-5, -0.01, 10)
    XX, YY = np.meshgrid(xs, ys)
    xi_grid = (XX + 1j*YY).flatten()

    w_jax = np.asarray(dispersion.wofz(xi_grid))
    w_sci = scipy.special.wofz(xi_grid)

    rel_err = np.abs(w_jax - w_sci) / np.maximum(np.abs(w_sci), 1e-12)
    worst = rel_err.max()
    median = np.median(rel_err)
    print(f"  [2.A lower HP] max rel_err = {worst:.2e}, median = {median:.2e}")
    # Lower HP via reflection — exponential factor amplifies errors.
    # Looser tolerance is justified; KEY's regime is |Im(xi)| < 2 anyway.
    assert worst < 1e-4, f"Lower-HP accuracy failed: worst rel_err = {worst:.2e}"


def test_milestone_2B_D0_D1_at_test_points():
    """D_0 and D_1 (Cheng resonant coefficients) evaluate without error.

    Full Julia-match reserved for after reference dataset is generated.
    Here we verify the functions are analytically consistent: when |xi|
    is very small, D_0 -> -1/(4 Omega_kappa) * Z'(0)/xi ~ finite; when
    |xi| is large, Z(xi) ~ -1/xi and D_1 -> -(1 - 1)/(4 Om_k) = 0.
    """
    Omega_kappa = 0.1 + 0j

    # Small xi: Z(xi) ≈ i*sqrt(pi) (Z at origin)
    xi_small = 0.01 + 0.01j
    D0_small = complex(dispersion.D0(xi_small, Omega_kappa))
    D1_small = complex(dispersion.D1(xi_small, Omega_kappa))
    # Z(0) = i*sqrt(pi), so D_0(0) = -i*sqrt(pi)/(4*0.1*0) — diverges
    # For xi_small = 0.01+0.01j, D_0 should be large but finite
    assert np.isfinite(D0_small.real) and np.isfinite(D0_small.imag)
    assert np.isfinite(D1_small.real) and np.isfinite(D1_small.imag)
    print(f"  [2.B small xi] D_0={D0_small:.3e}, D_1={D1_small:.3e}")

    # Large xi: asymptotically Z(xi) ~ -1/xi - 1/(2xi^3), so 1 + xi*Z(xi) -> 0
    xi_large = 5.0 + 0.5j
    D0_large = complex(dispersion.D0(xi_large, Omega_kappa))
    D1_large = complex(dispersion.D1(xi_large, Omega_kappa))
    # Check 1 + xi*Z(xi) is indeed small
    Z_large = complex(dispersion.Z(xi_large))
    residual = abs(1.0 + xi_large * Z_large)
    print(f"  [2.B large xi] |1 + xi*Z(xi)| = {residual:.3e}, D_1={D1_large:.3e}")
    assert residual < 0.5  # asymptotic behavior visible


def test_milestone_2C_jax_grad_finite():
    """Milestone 2.C: jax.grad flows through Z(xi) smoothly."""
    def f(x):
        xi = x + 1j * 0.1
        return dispersion.Z(xi).real
    g = jax.grad(f)(1.3)
    assert np.isfinite(float(g)), f"grad returned {g}"
    print(f"  [2.C grad at 1.3+0.1i] d(ReZ)/dx = {float(g):.4e}")

    # Also check jit
    jit_Z = jax.jit(dispersion.Z)
    out = complex(jit_Z(1.0 + 0.5j))
    assert np.isfinite(out.real) and np.isfinite(out.imag)
    print(f"  [2.C jit Z(1+0.5i)] = {out:.4e}")


def test_milestone_2D_marginal_stability_band():
    """Milestone 2.D: Z(xi) is smooth on the marginal-stability band
    gamma -> 0+, where the stKBM lives.

    This is the regime Mulholland Ch. 4 cares about most.
    """
    xs = np.linspace(-3, 3, 50)
    xi_band = xs + 0.001j  # gamma = 0.001 — just above marginality

    w_jax = np.asarray(dispersion.wofz(xi_band))
    w_sci = scipy.special.wofz(xi_band)
    rel_err = np.abs(w_jax - w_sci) / np.maximum(np.abs(w_sci), 1e-12)

    # Gradient smoothness check — compute d(ReZ)/dx at each point, should be continuous
    def f(x): return dispersion.Z(x + 0.001j).real
    g_fn = jax.grad(f)
    grads = np.array([float(g_fn(x)) for x in xs])
    # Check no NaN/Inf and no jumps of order 1e+10 between neighbors
    assert np.all(np.isfinite(grads)), "gradients are not all finite"
    dg = np.diff(grads)
    assert np.abs(dg).max() < 100, f"gradient jump of {np.abs(dg).max():.3e} detected — possible branch"
    print(f"  [2.D marginal band] max rel_err = {rel_err.max():.2e}, max |dg/dx| = {np.abs(dg).max():.2e}")


def test_bonus_vmap_flows():
    """Sanity: vmap over arrays works."""
    xi_array = jnp.array([1.0+0.1j, 2.0-0.3j, -0.5+1.0j, 0.1+0.01j])
    w_vmapped = jax.vmap(dispersion.wofz)(xi_array)
    w_direct = dispersion.wofz(xi_array)
    assert np.allclose(w_vmapped, w_direct, atol=1e-12), "vmap disagrees with direct call"
    print(f"  [bonus vmap] OK, shape = {w_vmapped.shape}")


if __name__ == "__main__":
    print("--- Milestone 2.A: Z(xi) vs scipy.special.wofz ---")
    test_milestone_2A_upper_half_plane()
    test_milestone_2A_real_axis()
    test_milestone_2A_lower_half_plane()
    print("--- Milestone 2.B: D_0, D_1 at endpoints ---")
    test_milestone_2B_D0_D1_at_test_points()
    print("--- Milestone 2.C: jax.grad finite ---")
    test_milestone_2C_jax_grad_finite()
    print("--- Milestone 2.D: marginal-stability band ---")
    test_milestone_2D_marginal_stability_band()
    print("--- Bonus: vmap ---")
    test_bonus_vmap_flows()
    print("\n*** All dispersion tests passed ***")
