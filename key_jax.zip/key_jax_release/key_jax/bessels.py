"""Bessel and Gamma functions used in the KBM Q integrals.

Convention (Mulholland Ch. 4 eq. 4.37, 4.38):
    Gamma_n(b) = I_n(b) * exp(-b)

where I_n is the modified Bessel function of the first kind and b is the
FLR argument:
    b = (1/2) k_perp^2 rho_thi^2  ≈  (1/2) k_y^2 rho_ref^2 * g^yy / B_hat^2

Implementation notes
--------------------
KEY caps b at 700 by hand to avoid overflow in besseli(0, b). This is a
Julia numerical choice — the actual physics just uses the scaled function
i0e(b) = I_0(b) * exp(-b), which is bounded and well-behaved for all b >= 0.
jax.scipy.special provides i0e and i1e that do this directly. We drop the cap.

At very large b (b >> 1), Gamma_0(b) ~ 1/sqrt(2 pi b) — the asymptotic FLR
suppression the Bessel function provides. We match this limit by using i0e
directly; KEY's capped version would return besseli(0, 700)*exp(-700) which
is a different number. This is a deliberate improvement, flagged in
test_milestone_3A_large_b below.
"""
from __future__ import annotations

import jax
import jax.numpy as jnp
import jax.scipy.special as jsp


def Gamma0(b: jax.Array) -> jax.Array:
    """Gamma_0(b) = I_0(b) * exp(-b). Mulholland eq. 4.37."""
    return jsp.i0e(b)


def Gamma1(b: jax.Array) -> jax.Array:
    """Gamma_1(b) = I_1(b) * exp(-b)."""
    return jsp.i1e(b)


def FLR_factor(b: jax.Array) -> jax.Array:
    """The FLR combination that appears in Mulholland eq. 4.46:
       [tau*Omega + 1 - eta_i/2] Gamma_0(b) + eta_i * b * (Gamma_1(b) - Gamma_0(b))

    Returned here just as the b-dependent part: Gamma_0(b) and
    b*(Gamma_1(b) - Gamma_0(b)) are what downstream q_integrals.py needs.
    """
    G0 = Gamma0(b)
    G1 = Gamma1(b)
    return G0, b * (G1 - G0)


def b_of(kyrho: float, gyy: jax.Array, B_hat: jax.Array) -> jax.Array:
    """Compute b(theta) = (1/2) k_y^2 rho_ref^2 * g^yy / B_hat^2.

    This is the definition used in KEY's main_key_equations.jl (the global
    `b_of_theta`). kyrho here is KEY convention (sqrt(2) * GENE's).
    """
    return 0.5 * kyrho**2 * gyy / (B_hat * B_hat)
